export default {
	auth: {
		loggedIn : false,
		busy:false,
		data:''
	},
	service: {
		busy:false,
		data:''
	}
}
